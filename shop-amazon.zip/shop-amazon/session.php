<?php 
session_start();
if(!isset($_SESSION['Customer_ID']) || (trim($_SESSION['Customer_ID']) == ''))
{
	header("location:register.php");
} 
?>