<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>
      AH-Mobiles
    </title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<form method = "post" >
  <h1>Administrator Log in</h1>
  <div class="inset">
  <p>
    <label for="">USERNAME</label>
    <input style = "color:white;" type="text" name="admin" id="">
  </p>
  <p>
    <label for="password">PASSWORD</label>
    <input style = "color:white;" type="password" name="password" id="password">
  </p>

  </div>
   <center><p class="p-container" >
    <input type="submit" name="go" id="go" value="Log in">
  </p>
  </center>
</form>
<?php
	include('connect.php');
	if(isset($_POST['go']))
	{	
		$username=$_POST['admin'];
		$password=$_POST['password'];
		$result = mysqli_query($conn,"SELECT * FROM admin WHERE username = '$username' AND password = '$password'") or die(mysql_error());
		$row = mysqli_fetch_array($result);
		$numberOfRows = mysqli_num_rows($result);				
		if ($numberOfRows == 0) 
		{
			echo " <br><center><h1><font color= 'red' size='3'>Imran Chawala na mar Password sai la....</font></h1></center>";
		} 
		else if ($numberOfRows > 0)
		{
			session_start();
			$_SESSION['id'] = $row['id'];
			header("location:user.php");
		}	
	}
?>
	



</body>
</html>
