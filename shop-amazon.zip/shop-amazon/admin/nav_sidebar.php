<nav class="navbar-default navbar-side" role="navigation">
	<div class="sidebar-collapse">
    	<ul class="nav" id="main-menu">
            <li>
                <a href="maincategory.php"><i class="fa fa-dashboard"></i> Main Category</a>
            </li>
            <li>
                <a href="subcategory.php"><i class="fa fa-gear"></i> Sub Category</a>
            </li>
            <li>
                <a href="product.php"><i class="fa fa-dashboard"></i>Products</a>
            </li>
            <li>
                <a href="neworder.php"><i class="fa fa-dashboard"></i> New Order </a>
            </li>
            <li>
                <a href="orderpending.php"><i class="fa fa-dashboard"></i> Order Pending</a>
            </li>
            <li>
                <a href="orderdeliver.php"><i class="fa fa-dashboard"></i> Order Delivered</a>
            </li>
            <li>
                <a href="user.php"><i class="fa fa-user"></i> Admin & User </a>
            </li>
               <li>
                <a href="logout.php"><i class="fa fa-user"></i> Log out </a>
            </li>
        </ul>
    </div>
</nav>