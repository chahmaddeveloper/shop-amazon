<?php
	include ('session.php');
	include('header.php');
	$get_id = $_GET['id'];
?>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">AH-Shopping</a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
              	<li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                      	Welcome : Administrator
                    </a>
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-5 well">
                        <div class="hero-unit-table">   
                          <div class="hero-unit-table">   
                            <?php 
                            $query = mysqli_query($conn,"SELECT * FROM products WHERE id ='$get_id'") or die(mysql_error());
                            $row = mysqli_fetch_array($query);
                            ?>
                            <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                <div class="alert alert-info"><strong>Edit Product</strong> </div>
                                <div class="control-group">
                                    <label class="control-label">Product Name</label>
                                    <div class="controls">
                                        <input type="text" name="name" class = "form-control" value="<?php echo $row['title']; ?>">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Description</label>
                                    <div class="controls">
                                        <input type="text" name="txtdes" class = "form-control" value="<?php echo $row['description']; ?>" />
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Price</label>
                                    <div class="controls">
                                        <input type="text" name="txtprice"  class = "form-control" value="<?php echo $row['price']; ?>">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Current Image</label>
                                    <div class="controls">
                                        <img src="../upload/<?php echo $row['img_path']; ?>" style="width:37px; height:35px;" />
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Image Update</label>
                                    <div class="controls">
                                        <input type="file" name="pic" class = "form-control" />
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Stock</label>
                                    <div class="controls">
                                        <input type="text" name="txtstock" class = "form-control" value="<?php echo $row['stock']; ?>" />
                                    </div>
                                </div>
                                <div class="control-group" style="margin-top:18px;">
                                    <div class="controls">
                                        <button type="submit" name="update" class="btn btn-success">
                                        	<i class="icon-save icon-large"></i>&nbsp;Update
                                        </button>
										<span><a href = "product.php" class = "btn btn-danger"> Back</a></span>
                                    </div>
                                </div>
                            </form>
                            <?php
                            if (isset($_POST['update'])) 
							{
								$target	= "../upload/";
								$pic    =  $_FILES['pic']['name'];
								if($pic)
								{
									if(move_uploaded_file($_FILES['pic']['tmp_name'],$target."".$pic))
									{
										$Query = "UPDATE products SET 
										title       = '".$_REQUEST['name']."', 
										description = '".$_REQUEST['txtdes']."', 
										price       = ".$_REQUEST['txtprice'].", 
										img_path    = '$pic',
										stock       = ".$_REQUEST['txtstock']."
										WHERE id    = '$get_id' ";
										mysqli_query($conn,$Query) or die( mysqli_query() );
									?>
                                    <script type="text/javascript">
                                        window.location.replace("product.php");
                                    </script>
									<?php
                                    }
									else
									{
									   echo " Sorry , there was a problem uploading your file .";
									}
								}
								else
								{
									if($row['img_path'])
									{	
										$pic = $row['img_path'];
										$Query = "UPDATE products SET 
										title       = '".$_REQUEST['name']."' , 
										description = '".$_REQUEST['txtdes']."', 
										price       = ".$_REQUEST['txtprice'].", 
										img_path    = '$pic',
										stock       = ".$_REQUEST['txtstock']."
										WHERE id    = '$get_id' ";
										mysqli_query($conn,$Query) or die(mysqli_query());
									?>
                                    
                                    <script type="text/javascript">
                                        window.location.replace("product.php");
                                    </script>
                                    
                                    <?php
									}
									else
									{
									   echo " Sorry , there was a problem in updating .";
									}
								}
								
							}
                            ?>
                        </div>
                        </div>
                	</div>
            	</div> 
            </div>
        </div>
    </div>
     <?php include ('script.php');?>
</body>
</html>
