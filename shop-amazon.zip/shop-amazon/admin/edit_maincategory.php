<?php include ('session.php');?>	
<?php
include('header.php');
$get_id = $_GET['id'];
?>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Ah-Shopping</a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                      						
					    Welcome : Administrator
                    </a>
                </li>
            </ul>
        </nav>
       <?php include ('nav_sidebar.php');?>
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-5 well">
                        <div class="hero-unit-table">   
                          <div class="hero-unit-table">   
                            <?php 
                            $query = mysqli_query($conn,"select * from product_menu where menu_id ='$get_id'") or die(mysql_error());
                            $row = mysqli_fetch_array($query);
                            ?>
                            <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                <div class="alert alert-info"><strong>Edit Main Category</strong> </div>
                                <div class="control-group">
                                    <label class="control-label">Main Category</label>
                                    <div class="controls">
                                        <input type="text" name="txtcategory" class = "form-control" value="<?php echo $row['product']; ?>">
                                    </div>
                                </div>
                                <div class="control-group" style="margin-top:10px">
                                    <div class="controls">
                                        <button type="submit" name="update" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Update</button>
										<span><a href = "maincategory.php" class = "btn btn-danger"> Back</a></span>
                                    </div>
                                </div>
                            </form>

                            <?php
                            if (isset($_POST['update'])) 
							{
                                mysqli_query($conn,"UPDATE product_menu SET 
								product = '".$_REQUEST['txtcategory']."' 
								WHERE menu_id ='$get_id' ") or die(mysql_query());
                                header('location:maincategory.php');
                            }
                            ?>
                        </div>
                        </div>
                        </div>
                    </div>
                </div> 
                
				
				</div>
            </div>
        </div>
   <?php include ('script.php');?>
</body>
</html>
