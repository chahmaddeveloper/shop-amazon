<?php 
	include('session.php');
	include('connect.php');
	include('header.php');
	$InviceID = $_GET['id']; 
?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header" style="background:#3c8dbc;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#	">AH-Shopping</a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                    	Welcome : Administrator
                    </a>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed table-striped table-bordered" id="dataTables-example">
                                <div class="alert alert-info">
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Ordering Products Detail</strong>
                                </div>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Pic</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($conn,"SELECT * FROM buycart WHERE inviceno = '".$InviceID."' ") or die(mysql_error());
                                    while ($Rstobj = mysqli_fetch_array($query)) 
									{
                                        $user_id = $Rstobj['inviceno'];
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $Rstobj['title']; ?></td>
                                            <td><?php echo $Rstobj['quantity']; ?></td>
                                            <td><?php echo $Rstobj['unitprice']; ?></td>
                                            <td>
												<img src="../upload/img/<?php echo $Rstobj['img_path']; ?>" alt="Img" style="width:50px; height:50px;" />
											</td>
                                            
                                    	</tr>
									<?php 
                                        } 
                                    ?>
                                    <tr>
                                    	<td>
                                        	<a href="confirmorder.php?id=<?php echo $user_id; ?>"><input type="submit" name="submitorder" value="Confirm Order" /></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                    	</div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
   <?php include ('script.php');?>
</body>
</html>