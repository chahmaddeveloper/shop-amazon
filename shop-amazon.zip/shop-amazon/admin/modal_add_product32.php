<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">    
            	<div class="alert alert-info"><strong><center>Add Care Center </center></strong></div>
        	</div>
        	<div class="modal-body">
				<form  method="post" enctype="multipart/form-data">
				<hr>
					<div class="control-group">
                        <label class="control-label" for="inputEmail">City Name:</label>
                        <input type="text" name="txtcityname" class = "form-control" placeholder="City">
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Care Center:</label>
                        <input type="text" name="txthospitalname" class = "form-control" placeholder="Care Center">
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Address:</label>
                        <input type="text" name="txtaddress" class = "form-control" placeholder="Address">
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Phone:</label>
                        <input type="text" name="txtphone" class = "form-control" placeholder="Phone">
                    </div>
                    <div class = "modal-footer">
                         <button type="submit" name= "go" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>                    
                    </div>
       			</form>
            </div>
        </div>  
	</div>
</div>
<?php 
if (isset($_POST['go'])) 
{
    mysqli_query($conn,"INSERT INTO health_center(id, cityname, care_center_name, phone, address) 
    VALUES('Null', '".$_REQUEST['txtcityname']."', '".$_REQUEST['txthospitalname']."', '".$_REQUEST['txtphone']."', '".$_REQUEST['txtaddress']."')") 
    or die(mysql_error());
    header('location:healthcarecenterl.php');
}
?>    
      
</div>
</div>