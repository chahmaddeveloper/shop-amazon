<script>
function showCustomer(str) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "getcustomer.php?q="+str, true);
  xhttp.send();
}
</script>


<script type="text/javascript" language="javascript">
function category()
{
	return (document.FormProduct.main.value);
}
</script>
<?php 
	 include('connect.php');
 ?>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">
            	<div class="alert alert-info"><strong><center>Add Products </center></strong></div>
            </div>
            <div class="modal-body">
            	<form name="FormProduct"  method="post" enctype="multipart/form-data">
            		<div class="control-group">
                    <label class="control-label" >Main Category:</label>
                    <div class="controls">
                    <select name="customers" class="form-control" onchange="showCustomer(this.value)" >
                        <?php 
                         $result = mysqli_query($conn,"SELECT * FROM product_menu");
                         while($row1 = mysqli_fetch_array($result))
                         {
                         ?>
                         <option value="<?php echo $row1['menu_id']; ?>"> 
                            <?php echo $row1['product']; ?>
                         </option>
                         <?php
                         }
                         ?>
                    </select>
                    </div>
                </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Sub Category:</label>
                        <div class="controls" id="txtHint" >
                            
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Product Name:</label>
                        <div class="controls">
                            <input type="text" name="name"  class = "form-control" placeholder="Product Name" >
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Description:</label>
                        <div class="controls">
                            <input type="text" name="txtdescription"  class = "form-control" placeholder="Description" >
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Price:</label>
                        <div class="controls">
                            <input type="text" name="txtprice"  class = "form-control" placeholder="Price" >
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Pic:</label>
                        <div class="controls">
                            <input type="file" name="pic"  class="form-control" >
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Stock:</label>
                        <div class="controls">
                            <input type="text" name="txtstock"  class = "form-control" placeholder="Stock" >
                        </div>
                    </div>
                    <div class = "modal-footer">
                        <button  name = "go" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
            	</form>
            </div>
        </div>  								  
    </div>
</div>
<?php 
if (isset($_POST['go'])) 
{
    $target	= "../upload/";
    $pic    =  $_FILES['pic']['name'];
    if(move_uploaded_file($_FILES['pic']['tmp_name'],$target."".$pic))
    {
        $Query  = "INSERT INTO products(id, menu_id, sub_id, title, description, price, img_path, stock, status) 
        Values('Null', '".$_POST['main']."', '".$_POST['sub']."', '".$_POST['name']."', 
        '".$_POST['txtdescription']."', '".$_POST['txtprice']."', '$pic', '".$_POST['txtstock']."', 0) ";
        mysqli_query($conn,$Query) or die( mysqli_error() );
    ?>
    <script type="text/javascript">
      window.location.replace("product.php");
    </script>
    <?php
    }   
    else
    {
       echo " Sorry , there was a problem uploading your file .";
    }
}
?>