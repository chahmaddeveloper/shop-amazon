<?php 
	include('session.php');
	include('connect.php');
	include('header.php');
?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header" style="background:#3c8dbc;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#	">AH-Shopping</a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                    	Welcome : Administrator
                    </a>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed table-striped table-bordered" id="dataTables-example">
                                <div class="alert alert-info">
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Pending Orders</strong>
                                </div>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>City</th>
                                        <th>Town</th>
                                        <th>Phone</th>
                                        <th>Total Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($conn,"SELECT * FROM billingcart WHERE status = 1 ") or die(mysql_error());
                                    while ($Rstobj = mysqli_fetch_array($query)) 
									{	
										$user_id = $Rstobj['customer_id'];
										$query1 = mysqli_query($conn,"SELECT * FROM customeronline WHERE customer_id =".$user_id) or die(mysql_error());
                                    	while ($Rstobj1 = mysqli_fetch_array($query1)) 
										{
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $Rstobj1['firstname']; ?></td>
                                            <td><?php echo $Rstobj1['city']; ?></td>
                                            <td><?php echo $Rstobj1['town']; ?></td>
                                            <td><?php echo $Rstobj1['phone']; ?></td>
                                            <td><?php echo $Rstobj['totalamount']; ?></td>
                                            <td width="80">
                                            	<a href="orderdeposit.php?id=<?php echo $Rstobj['inviceno']; ?>" style="color:blue; font-size:20px; padding:10px;">
                                                	<i class="fa fa-anchor"></i>
                                                </a>
                                            </td>
                                    	</tr>
									<?php 
										}
									} 
                                    ?>
                                </tbody>
                            </table>
                    	</div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
   <?php include ('script.php');?>
</body>
</html>
