<?php 
	include ('connect.php');
	$ID = $_REQUEST['id'];
	$Query = "DELETE FROM products WHERE id=".$ID;
	mysqli_query($conn,$Query);
?>
<script type="text/javascript">
	window.location.replace("product.php");
</script>