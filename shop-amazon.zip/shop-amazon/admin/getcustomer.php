	<?php 
	 include('connect.php');
 	?>
    
    <select name="customersub" class="form-control">
		<?php
 		$IdQ = $_GET['q'];
        $result = mysqli_query($conn,"SELECT * FROM product_sub WHERE  menu_id = ".$IdQ." ");
		while($row1 = mysqli_fetch_array($result))
		{
		?>
			<option value="<?php echo $row1['sub_id']; ?>">
				<?php echo $row1['product']; ?>
			</option>
		 <?php
		 }
		 ?>
	</select>
