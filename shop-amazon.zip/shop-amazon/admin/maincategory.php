<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header" style="background:#3c8dbc;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#	">AH-Shopping</a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                    	Welcome : Administrator
                    </a>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
							 <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                              Add Main Category
                            </button>
							
						 </h1>
						<?php  include ('modal_add_maincategory.php');?>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed table-striped table-bordered" id="dataTables-example">
                                <div class="alert alert-info">
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Main category Table</strong>
                                </div>
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($conn,"select * FROM product_menu") or die(mysql_error());
                                    while ($Rstobj = mysqli_fetch_array($query)) {
                                        $user_id = $Rstobj['menu_id'];
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $Rstobj['product']; ?></td> 
                                            <td width="80">
                                    			<a href="delete_maincategory.php?id=<?php echo $Rstobj['menu_id']; ?>"  style="color:#C00; font-size:20px; padding:10px;"><i class="fa fa-times"></i></a>
                                            	<a href="edit_maincategory.php?id=<?php echo $Rstobj['menu_id']; ?>" style="color:blue; font-size:20px; padding:10px;"><i class="fa fa-pencil-square-o"></i></a>        	
                                            </td>
                                            <!-- user delete modal -->
                                    
                                    <!-- end delete modal -->

                                    </tr>
									
                                <?php } ?>
                                </tbody>
                            </table>
                    	</div>
                    </div>
                </div> 
                
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
