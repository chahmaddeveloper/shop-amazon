<?php 
	include ('connect.php');
	$ID = $_REQUEST['id'];
	$Query = "UPDATE billingcart SET status = 1 WHERE inviceno= '".$ID."' ";
	mysqli_query($conn,$Query);
	header("location:neworder.php");
?>