<?php 
	include('session.php');
	include('connect.php');
	include('header.php');
?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header" style="background:#3c8dbc;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#	">AH-Shopping</a>
            </div>
            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                    	Welcome : Administrator
                    </a>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
							 <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                              Add Our Products
                            </button>
                        </h1>
                        <?php  
						  include('modal_add_productdes.php');
						?>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed table-striped table-bordered" id="dataTables-example">
                                <div class="alert alert-info">
                                    <strong><i class="icon-user icon-large"></i>&nbsp;Our Product</strong>
                                </div>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Pic</th>
                                        <th>Stock</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($conn,"SELECT * FROM products") or die(mysql_error());
                                    while ($Rstobj = mysqli_fetch_array($query)) 
									{
                                        $user_id = $Rstobj['id'];
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $Rstobj['title']; ?></td>
                                            <td><?php echo $Rstobj['description']; ?></td>
                                            <td><?php echo $Rstobj['price']; ?></td>
                                            <td>
												<img src="../upload/<?php echo $Rstobj['img_path']; ?>" alt="Img" style="width:30px; height:30px;" />
											</td>
                                            <td><?php echo $Rstobj['stock']; ?></td>
                                            <td width="80">
                                    			<a href="delete_product.php?id=<?php echo $Rstobj['id']; ?>"  style="color:#C00; font-size:20px; padding:10px;"><i class="fa fa-times"></i></a>
                                            	<a href="edit_product.php?id=<?php echo $Rstobj['id']; ?>" style="color:blue; font-size:20px; padding:10px;"><i class="fa fa-pencil-square-o"></i></a>        	
                                            </td>
                                    	</tr>
									<?php 
                                     } 
                                    ?>
                                </tbody>
                            </table>
                    	</div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
   <?php include ('script.php');?>
</body>
</html>
