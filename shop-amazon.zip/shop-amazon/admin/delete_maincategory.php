<?php 
	include ('connect.php');
	$ID = $_REQUEST['id'];
	$Query = "DELETE FROM product_menu WHERE menu_id=".$ID;
	mysqli_query($conn,$Query);
?>
<script type="text/javascript">
	window.location.replace("maincategory.php");
</script>
