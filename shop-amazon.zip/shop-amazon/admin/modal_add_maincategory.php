<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              
                <div class="alert alert-info"><strong><center>Add Main Category </center></strong></div>
            </div>
            <div class="modal-body">
  <form  method="post" enctype="multipart/form-data">
    <div class="control-group">
        <label class="control-label" for="inputPassword">Main Category Name:</label>
        <div class="controls">
            <input type="text" name="product"  class = "form-control" placeholder="Main Category" >
        </div>
    </div>
    <div class = "modal-footer">
         <button name = "go" class="btn btn-primary">Add</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	</div>
</div>
         
              
          
        </div>
        
          </form>  
          
           <?php 
if (isset($_POST['go'])) {

    $name = $_POST['product'];

    //image
    $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
    $image_name = addslashes($_FILES['image']['name']);
    $image_size = getimagesize($_FILES['image']['tmp_name']);
//
    move_uploaded_file($_FILES["image"]["tmp_name"], "upload/" . $_FILES["image"]["name"]);
    $location = "upload/" . $_FILES["image"]["name"];


    mysqli_query($conn,"insert into product_menu(menu_id, product)
    values ('Null','$name')") or die(mysql_error());

    header('location:maincategory.php');
}
?>
    </div>
</div>