<?php
include('connect.php');

$get_id = $_GET['id'];

mysqli_query($conn,"delete from sub_categories where id='$get_id'")or die(mysql_error());
header('location:productsub.php');
?>
