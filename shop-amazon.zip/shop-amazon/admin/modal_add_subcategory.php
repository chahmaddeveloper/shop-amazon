<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">              
                <div class="alert alert-info">
                    <strong><center>Add Sub Category </center></strong>
                </div>
            </div>
            <div class="modal-body">
                <form  method="post" enctype="multipart/form-data"> 
				    <div class="control-group">
                        <label class="control-label" for="inputPassword">Main Category:</label>
                        <div class="controls">
                            <select name="category" class = "form-control" >
                                <?php 
    							include('connect.php');
    							$result = mysqli_query($conn,"select * from product_menu");
               					while($row1 = mysqli_fetch_array($result))
    							{
    							?>
                                <option value="<?php echo $row1['menu_id']; ?>">
                                    <?php echo $row1['product']; ?>
                                </option>
                                <?php
    							}
    							?>
                            </select>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Sub Category:</label>
                        <div class="controls">
                            <input type="text" name="subcategory" class="form-control" placeholder="Sub Category">
                        </div>
                    </div>
                    <div class = "modal-footer">
    					<button name = "go" class="btn btn-primary">Save</button>
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
		        </form>  
            </div>
        </div> 
		<?php 
        if (isset($_POST['go'])) 
		{
			$Query  = "INSERT INTO product_sub(menu_id, sub_id, product) 
			Values(".$_REQUEST['category'].", Null, '".$_REQUEST['subcategory']."' )";
			$Result = mysqli_query($conn,$Query) or die(mysql_error());
            header('location:subcategory.php');
        }
        ?>  
    </div>
</div>