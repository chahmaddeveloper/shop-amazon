<?php

    $db = @mysql_connect('localhost', 'root', '') or die(mysql_error());
    @mysql_select_db('doctor_patient_portal', $db) or die(mysql_error());
 
?>
