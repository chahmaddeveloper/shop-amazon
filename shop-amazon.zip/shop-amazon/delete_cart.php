<?php
	ob_start();
	include('lib/opencon.php');
	$DelProduct = $_GET['id'];
	$Query  = "DELETE FROM addcart WHERE product_id =".$DelProduct;
	mysqli_query($conn,$Query);
	header("location:index.php");
?>