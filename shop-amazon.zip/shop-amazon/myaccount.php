<?php
	ob_start();
	$PageName = "";
	$Path = "";
	include('lib/opencon.php');
	
	if(!isset($_GET['id']))
	{
		$ReqID = "";
	}
	else
	{
		$ReqID = $_GET['id'];
		if($ReqID == 'done')
		{
			$ReqID = "You have successfully updated your account ";
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $Title; ?></title>
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
	<script type="text/javascript" language="javascript">
    function updatesaccount()
    {  
        if(document.FormUpdate.txtfname.value == "" )
        {
            alert("Please Enter First Name ! ");
            document.FormUpdate.txtfname.focus();
            return false;
        }
        if(document.FormUpdate.txtfname.value != "" )
        {
            if( isNaN(document.FormUpdate.txtfname.value) == false )
            {
                alert("Please Enter First Name In Alphabates ! ");
                document.FormUpdate.txtfname.focus();
                return false;
            }
            else if( isNaN(document.FormUpdate.txtfname.value) == true )
            {
                if(document.FormUpdate.txtfname.value.length <= 2 )
                {
                    alert("Name Must Be Greater Than 2 Letters  ! ");
                    document.FormUpdate.txtfname.focus();
                    return false;
                }
            }
        }
		if(document.FormUpdate.txtlname.value == "")
		{
			alert("Please enter last name");
		    document.FormUpdate.txtlname.focus();
		    return false;
		}
		if(document.FormUpdate.txtlname.value != "" )
        {
            if( isNaN(document.FormUpdate.txtlname.value) == false )
            {
                alert("Please Enter Last Name In Alphabates ! ");
                document.FormUpdate.txtlname.focus();
                return false;
            }
            else if( isNaN(document.FormUpdate.txtlname.value) == true )
            {
                if(document.FormUpdate.txtlname.value.length <= 1 )
                {
                    alert("Name Must Be Greater Than 1 Letters  ! ");
                    document.FormUpdate.txtlname.focus();
                    return false;
                }
            }
        }
		if(document.FormUpdate.txtmail.value == "")
		{
		    alert("Please Enter E-mail ! ");
		    document.FormUpdate.txtmail.focus();
		    return false;  
		}
		if(document.FormUpdate.txtmail.value != "" )
        {
			if(document.FormUpdate.txtmail.value.length <= 7 )
			{
				alert("E-Mail At Least Contain 8 Words  ! ");
				document.FormUpdate.txtmail.focus();
				return false;
			}
        }
		if(document.FormUpdate.txtpassword.value == "")
		{
		    alert("Please Enter Password");
		    document.FormUpdate.txtpassword.focus();
		    return false;  
		}
		if(document.FormUpdate.txtpassword.value != "" )
        {
			if(document.FormUpdate.txtpassword.value.length <= 7 )
			{
				alert("Password At Least Contain 8 Words  ! ");
				document.FormUpdate.txtpassword.focus();
				return false;
			}
        }
		if(document.FormUpdate.txtaddress.value == "")
		{
		    alert("Please Enter Address");
		    document.FormUpdate.txtaddress.focus();
		    return false;  
		}
		if(document.FormUpdate.txttown.value == "")
		{
		    alert("Please Enter Town");
		    document.FormUpdate.txttown.focus();
		    return false;
		}
		if(document.FormUpdate.txtcity.value == "")
		{
		    alert("Please Enter City");
		    document.FormUpdate.txtcity.focus();
		    return false;
		}
		if(document.FormUpdate.txtphone.value == "")
		{
		    alert("Please Enter Phone Number");
		    document.FormUpdate.txtphone.focus();
		    return false;  
		}
		if(document.FormUpdate.txtphone.value != "")
		{
		    if( isNaN(document.FormUpdate.txtphone.value) == true )
            {
                alert("Please Enter Correct Mobile Number Becuase Online Shopping Order Confirmation Is Send On Your Mobile ! ");
                document.FormUpdate.txtcountry.focus();
                return false;
            }
            else if( isNaN(document.FormUpdate.txtphone.value) == false )
            {
                if(document.FormUpdate.txtcountry.value.length <= 3 )
                {
                    alert("Please Enter Full And Correct Mobile Number ! ");
                    document.FormUpdate.txtcountry.focus();
                    return false;
                }
            }  
		}
		if(document.FormUpdate.txtcountry.value == "")
		{
		    alert("Please Enter Country");
		    document.FormUpdate.txtcountry.focus();
		    return false;
		}
		if(document.FormUpdate.txtcountry.value != "")
		{
			if( isNaN(document.FormUpdate.txtcountry.value) == false )
            {
                alert("Please Enter Correct Country Name ! ");
                document.FormUpdate.txtcountry.focus();
                return false;
            }
            else if( isNaN(document.FormUpdate.txtcountry.value) == true )
            {
                if(document.FormUpdate.txtcountry.value.length <= 3 )
                {
                    alert("Please Enter Full And Correct Country Name ! ");
                    document.FormUpdate.txtcountry.focus();
                    return false;
                }
            }
		}
    }
	function PasswordCheck()
	{
		if(document.FormUpdate.txtpassword.value != document.FormUpdate.txtconpassword.value)
		{
			alert("Confirm Password Does Not Match With New Password!");
			document.FormUpdate.txtconpassword.focus();
            return false;
		}
	}
	function CurrentPassword()
	{
		if(document.FormUpdate.txthidpassword.value != document.FormUpdate.txtcurpassword.value)
		{
			alert("Current Password Does Not Match !");
			document.FormUpdate.txtcurpassword.focus();
            return false;
		}
	}
    </script>	
</head>
<body>
	<?php include('session.php'); ?>
    <div class="row_100">
        <header>
            <?php 
				include('header.php'); 
			?>
        </header>
        <div class="row_100" style="box-shadow:0px 0px 2px 1px #CCCCCC;">        
            <div class="row">
                <div class="container">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 x_20">
                        <form name="FormUpdate" method="post" action="">	
                            <div class="row_99 border_1" style="border-radius:13px;">
                                <div class="row_100" style="background:#0085c3; border-radius:13px;">
                                    <h2 style="color:#fff;"><center>My Account</center></h2>
                                </div>
                                <?php
                                $Query  = "SELECT * FROM customeronline WHERE customer_id =".$Sess_ID;
                                $Result = mysqli_query($conn,$Query);
                                if(mysqli_num_rows($Result) > 0)
                                {
                                    $Rstobj = mysqli_fetch_array($Result);
                                    if(!isset($_REQUEST['edit']))
                                    {
                                    ?>
                                        <div class="row_95 x_20">
                                            <h4><a><?php echo $ReqID; ?></a></h4>
                                        </div>
                                        <div class="row_95 x_05">
                                            <div class="float_left col_40 label1">
                                                First Name* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['firstname']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Last Name* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text"  readonly="readonly" value="<?php echo $Rstobj['lastname']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                E-mail* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="email" readonly="readonly" value="<?php echo $Rstobj['email']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Current Password* &nbsp;&nbsp; &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="password" value="" readonly="readonly" class="input_reg"  />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                New Password* &nbsp;&nbsp; &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="password" class="input_reg" value="" readonly="readonly" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Confirm Password* &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="password" class="input_reg" value="" readonly="readonly" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Address* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['address']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Town* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['town']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                City* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['city']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Phone* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['phone']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Country* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" readonly="readonly" value="<?php echo $Rstobj['country']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_80 x_10"></div>
                                        <div class="row_80 x_10"></div>
                                        <div class="row_95">
                                            <div class="col_40 float_left x_05"></div>
                                            <div class="col_60 float_left"><input type="submit" name="edit" class="button" value="Edit Account"  /></div>
                                        </div>
                                        <div class="row_80 x_20"></div>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                        <div class="row_90 x_20"></div>
                                        <div class="row_95 x_05">
                                            <div class="float_left col_40 label1">
                                                First Name* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtfname" value="<?php echo $Rstobj['firstname']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Last Name* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtlname" value="<?php echo $Rstobj['lastname']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                E-mail* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="email" name="txtmail" value="<?php echo $Rstobj['email']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Current Password* &nbsp;&nbsp; &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="hidden" name="txthidpassword" value="<?php echo $Rstobj['password']; ?>"  />
                                                <input type="password" name="txtcurpassword" class="input_reg"  />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                New Password* &nbsp;&nbsp; &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="password" name="txtpassword" class="input_reg" onclick="return CurrentPassword();" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Confirm Password* &nbsp;
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="password" name="txtconpassword" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Address* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtaddress" value="<?php echo $Rstobj['address']; ?>" onclick="return PasswordCheck();" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Town* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txttown" value="<?php echo $Rstobj['town']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                City* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtcity" value="<?php echo $Rstobj['city']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Phone* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtphone" value="<?php echo $Rstobj['phone']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_95 x_10">
                                            <div class="float_left col_40 label1">
                                                Country* &nbsp; &nbsp; 
                                            </div>
                                            <div class="float_left col_60">
                                                <input type="text" name="txtcountry" value="<?php echo $Rstobj['country']; ?>" class="input_reg" />
                                            </div>
                                        </div>
                                        <div class="row_80 x_10"></div>
                                        <div class="row_80 x_10"></div>
                                        <div class="row_95">
                                            <div class="col_40 float_left x_05"></div>
                                            <div class="col_60 float_left">
                                                <input type="submit" onclick="return updatesaccount();"  name="updateaccount" class="button" value="Update Account"  />
                                            </div>
                                        </div>
                                        <div class="row_80 x_20"></div>
                                    <?php
                                    }
                                }
                                ?>
                            </div>
                        </form>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div> 
                </div>
            </div>
        </div>
    </div>
    <div>
    	<?php include('footer.php'); ?>
	</div>
</body>
</html>
<?php
	if(isset($_POST['updateaccount']))
	{
		$Query = "UPDATE customeronline SET firstname = '".$_POST['txtfname']."', lastname = '".$_POST['txtlname']."', 
		email = '".$_POST['txtmail']."', password = '".$_POST['txtpassword']."', address = '".$_POST['txtaddress']."', town = '".$_POST['txttown']."', 
		city = '".$_POST['txtcity']."', phone = '".$_POST['txtphone']."', country = '".$_POST['txtcountry']."', update_date = '".date("d:m:Y :: h:i:s")."' 
		WHERE customer_id ='$Sess_ID' ";
		mysqli_query($conn,$Query);
		$Message = "done";
		header("location:myaccount.php?id=$Message");
	}
?>