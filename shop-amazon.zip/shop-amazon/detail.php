<?php
	ob_start();
	session_start();
	$PageName = "detail.php";
	$Path = "";
	include('lib/opencon.php');
	$ReqProduct = $_GET['idproduct'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo $Title; ?></title>
    
    <link href="css/font-awesome.css" rel="stylesheet" />
    
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
    <!-- Slider -->
    
    <!-- validation -->
	<script type="text/javascript" language="javascript">
    	function checkqty()
		{  
			if(document.FORMQTY.txtQty.value == "")
			{
			  alert("Please Enter Qunatity ! ");
			  document.FORMQTY.txtQty.focus();
			  return false;
			}
			else if( isNaN(document.FORMQTY.txtQty.value) == true )
			{	
				alert("Please Enter Qauntity In Digit ! ");
				document.FORMQTY.txtQty.focus();
				return false;
			}
			else if( isNaN(document.FORMQTY.txtQty.value) == false )
			{
				if(document.FORMQTY.txtQty.value == 0)
				{
					alert("Please Enter Quantity Greater Than Zero ! ");
				    document.FORMQTY.txtQty.focus();
				    return false;
				}
				else if(document.FORMQTY.txtQty.value < 0)
				{
					alert("Please Enter Quantity In +Ve Digit ! ");
				    document.FORMQTY.txtQty.focus();
				    return false;
				}
				else if(document.FORMQTY.txtQty.value >= 20)
				{
					alert("Please Enter Quantity Less Than 20 ! ");
				    document.FORMQTY.txtQty.focus();
				    return false;
				}
				else if(document.FORMQTY.txtQty.value > 0 && document.FORMQTY.txtQty.value < 20)
				{
					return true;
				}
			}
		}
    </script>
</head>

<body>
	<div class="row_100" style="padding:0px 0px; margin:0px 0px; top:0; width:100%;">
        <?php 
            include('header.php');
        ?>
    </div>
	<?php 
        include('navbar2.php');
    ?>
    <div class="row_100">
    	<div class="wrapper">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30">
                    <div class="row_100">
                        <small class="txt_37">
                            <i  style="font-size:36px; color:#0085c3; text-shadow:none;" class="fa fa-cart-plus"></i> 
                            &nbsp; Our Products
                        </small>
                    </div>
                    <div class="row_100 x_10">
                    <?php
                    $Query  = "SELECT * FROM products WHERE id =".$ReqProduct;
                    $Result = mysqli_query($conn,$Query);
                    if(mysqli_num_rows($Result) > 0)
                    {
                        while($RstObj = mysqli_fetch_array($Result))
                        {
                            $ProductID = $RstObj['id'];
                        ?>
                            <div class="col-lg-4 col-md-5 col-sm-6 col-xs-12 x_10">
                                <div class="row_100 banner3 shadow">
                                    <div class="row_100 x_02 left_02 right_02 bottom_02">
                                        <div class="row_100" style="height:260px;">
                                            <img src="upload/<?php echo $RstObj['img_path']; ?>" 
                                            alt="<?php echo $RstObj['title']; ?>" 
                                            style="height:260px; width:100%;" />
                                        </div>
                                        <div class="row_100 bg_banner">
                                            <div class="row_97">
                                                <div class="row_100">
                                                    <div class="row_100">
                                                        <span class="txt_manager1"><?php echo $RstObj['title']; ?></span>
                                                    </div>
                                                    <div class="row_100" style="padding:5px 0px;">
                                                        <small class="txt_description"><?php echo $RstObj['description']; ?></small>
                                                    </div>
                                                    <div class="row_100">
                                                        <div class="col_50 float_left">
                                                            <span class="txt_manager3">RS. 
                                                                <span class="txt_manager2"><?php echo $RstObj['price']; ?></span>
                                                            </span>
                                                        </div>
                                                        <div class="col_50 float_left x_05" style="text-align:right;"></div>
                                                    </div>
                                                    <form name="FORMQTY" method="post">
													<?php
                                                    if(!isset($_SESSION['Customer_ID']))
                                                    {
                                                    ?>
                                                    <center>
                                                        <a href="register.php" >
                                                            <input type="button" value="Add To Cart" class="button" />
                                                        </a>
                                                    </center>
                                                    <?php
                                                    }
                                                    else
                                                    {
                                                    ?>
                                                    <div class="row_100">
                                                        <div class="col_40 float_left">
                                                            <div class="row_90">
                                                                <input type="number" maxlength="2" max="20" min="0"  name="txtQty" placeholder="0" 
                                                                class="input_amount"  />
                                                            </div>
                                                        </div>
                                                        <div class="col_60 float_left" style="text-align:right;">
                                                            <input type="submit" name="cart" onclick="return checkqty();" value="Buy Now" class="button1" />
                                                        </div>
                                                    </div>
                                                    <?php
                                                    }
                                                    ?>
                                                    </form>
                                                </div>
                                                <div class="row_100 x_10"></div>
                                            </div>
                                        </div>
                                    </div>        
                                </div>
                                <div style="padding-top:7px;"></div>
                            </div>
                        <?php
                            }
                        }
                        else
                        {
                        ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_10">
                                <h4 class="txt_msg">Sorry! No Product Exist In Stock....</h4>
                            </div>
                        <?php	
                        }
                        ?>
                    </div>
                </div>
                <div class="row_100 x_45"></div>
                <div class="row_100 x_45"></div> 
            </div>
        </div>   
    </div>
    <div class="row_100" >
        <?php include('footer.php'); ?>
	</div>
</body>
</html>
<?php
	if(isset($_POST['cart']))
	{
		$Query  = "SELECT * FROM billingcart";
		$Result = mysql_query($Query);
		$RstRow = mysql_num_rows($Result);
		$RstRow = $RstRow +1;
		$RstRow = "InvNo".$RstRow;
		$Query  = "SELECT * FROM products WHERE id=".$ProductID;
		$Result = mysql_query($Query);
		$RstObj = mysql_fetch_array($Result);
		$TotalAmount = $_POST['txtQty'] * $RstObj['price'];
		$Query  = "INSERT INTO addcart(inviceno,customer_id, product_id, title, img_path, quantity, unitprice, totalamount) 
				  Values('".$RstRow."', ".$CustomerId.", ".$ProductID.", '".$RstObj['title']."', '".$RstObj['img_path']."', ".$_POST['txtQty'].", 
				  ".$RstObj['price'].", ".$TotalAmount.")";
		$Result = mysql_query($Query);
		header('location:index.php');
	}
?>