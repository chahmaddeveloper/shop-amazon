<?php
	ob_start();
	session_start();
	$PageName = "submitfile.php";
	$Path = "";
	include('lib/opencon.php');
	$CustomerID = $_GET['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AH-Shopping</title>
    <link href="css/font-awesome.css" rel="stylesheet" />
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
    <!-- Slider -->
</head>
<body>
	<div style="padding:0px 0px; margin:0px 0px; top:0; width:100%;">
        <?php 
            include('header.php');
        ?>
    </div>
    <?php 
        include('navbar2.php');
    ?>
    <div class="row_100" style="box-shadow:0px 0px 2px 1px #CCCCCC;">
    	<div class="wrapper">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30">
                    <div class="row_100 x_20">
                        <div class="col-lg-8 col-md-9 col-sm-11 col-xs-12 x_10">
                            <h2 style="color:#999;">
                                Order Submitted...
                            </h2>
                            <small style="color:#999; font-size:19px;">
                            	You order is submitted successfully...! <br />
                            	Thank you for using our website...! <br />
                            	Regards: Laptop Channel <br />
                            </small>
                        </div>		
                    </div>
                    </form>
                </div>
            </div>    
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_45"></div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_45"></div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_45"></div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30"></div> 
        </div>
    </div>
    <div>
        <?php include('footer.php'); ?>
	</div>
</body>
</html>