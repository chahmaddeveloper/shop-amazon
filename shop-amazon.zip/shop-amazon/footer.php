<div class="footer2">
    <div class="wrapper">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_10">
                <ul class="footerlist">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Contact us</a></li>
                    <li><a href="#">Privacy</a></li>
                    <li><a href="#">Company</a></li>
                    <li><a href="#">Term</a></li>
                    <li><a href="#">Conditions</a></li>
                    <li><a href="#">Guide</a></li>
                </ul>
            </div>
            <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 x_20">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_05">
                    <ul class="iconi">
                        <li>
                            <a href="Facebook">
                                <div class="icon-div">
                                    <i class="fa fa-facebook-f"></i>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" title="Twitter">
                                <div class="icon-div">
                                    <i class="fa fa-twitter"></i>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="mailto:info@laptopchannel.com.pk" title="Email">
                                <div class="icon-div">
                                    <i class="fa fa-mail-reply-all"></i>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>        
            </div>
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 x_30">
                <img src="images/Untitled-1.png" style="float:right; width:232px; height:40;px" />
            </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30"></div>
	</div>
</div>    
<div class="footer1">
    <div class="wrapper">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bottom_05">
                <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 x_05">
                    <h6 class="txt_reserved">© <?php  echo date("Y"); ?>. All right reserved.</h6>
                </div>
                <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0 x_05"></div>
                <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 x_05" style="text-align:right;">
                    <a href="mailto:ahmadraza.aryain@hotmail.com" class="txt_devlop">
                    	<h6 class="txt_desgn">Ahmad Raza </h6></a>
                </div>
            </div>
        </div>
	</div>        
</div>    