<script type="text/javascript">
function SearchProduct()
{
	if(document.FormSearch.txtproduct.value == 0 )
	{
		alert("Enter Prodcut Name ! ");
		document.FormSearch.txtproduct.focus();	
		return false;
	}
}	
</script>
<link href="css/font-awesome.css" rel="stylesheet" />
<div class="row_100 x_10" style="text-align:right; background:#232f3e;">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"></div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    	<form name="FormSearch" method="post">
            <center>
            <div class="input_search-div">
            	<div class="float_left" style="width:351px; height:36px">
                	<input type="search"  name="txtproduct" class="input_search" placeholder="Search Products"  />
                </div>
                <div class="float_left" style="width:50px; height:36px;">
                	<button type="submit" name="BtnSearch" onclick="return SearchProduct();" class="search-btn" ><i class="fa fa-search"></i></button>
            	</div>
            </div>
            </center>
        </form>
    </div>
</div>
<div  class="row_100">
    <nav class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="z-index:1300;">
        	<div class="wrapper">
                <ul class="nav navbar-nav pull-left">
                    <li><a href="#"><small style="color:#CCC; font-size:22px;"><span style="color:#ffffff;">Shop</span> Mall</small></a></li>
                </ul>
                <ul class="nav navbar-nav pull-right">
                <?php 
                if(!isset($_SESSION['Customer_ID']))
                {
                ?>    
                    <li><a href="index.php"><i> Home</i></a></li>
                    <li><a href="products.php"><i> Products</i></a></li>
                    <li><a href="productstop.php"><i> Top Products</i></a></li>
                    <li><a href="register.php"><i> Log In</i></a></li>
                <?php
                }
                else
                {
                    $Sess_ID    = $_SESSION['Customer_ID'];
                    $CustomerId = $_SESSION['Customer_ID'];
                ?>
                    <li><a href="index.php"><i> Home</i></a></li>
                    <li><a href="products.php"><i> Products</i></a></li>
                    <li><a href="myaccount.php"><i> My Profile</i></a></li>
                    <li><a href="#"><i data-toggle="modal" data-target="#myModal"> Shopping Cart</i></a></li>
                    <?php include('modal_cart.php'); ?>
                    <li><a href="logout.php"><i> Log Out</i></a></li>
                <?php
                }
                ?>
                </ul>
        	</div>
        </div>
    </nav>
</div>
<?php
	if(isset($_REQUEST['BtnSearch']))
	{
		$ProductID = $_REQUEST['txtproduct'];
		header("location:searchproduct.php?productname=$ProductID");
	}
?>