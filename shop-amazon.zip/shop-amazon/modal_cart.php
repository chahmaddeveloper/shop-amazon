<?php
	include('lib/opencon.php');
	$CustomerId = $_SESSION['Customer_ID'];
?>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="z-index:1030;">
	<div class="modal-dialog">
    	<div class="modal-content" style="background:#E6E6E6">
        	<div class="modal-header">    
            	<div class="alert alert-info" style="font-size:18px; color:#FFF; background:#0085c3;">
                	<center>Recently added products (Cart)</center>
                </div>
        	</div>
        	<div class="modal-body">
				<form name="form" method="post" enctype="multipart/form-data">
					<div class="control-group" style="margin-top:-19px;">
                        <?php
							$Amount = 0;
							$Query  = "SELECT * FROM addcart WHERE customer_id=".$CustomerId;
							$Result = mysqli_query($conn,$Query);
							if(mysqli_num_rows($Result) > 0)
							{
								while($RstObj = mysqli_fetch_array($Result))
								{
									$ItemID = $RstObj['product_id'];
								?>
                                <div class="row_100">
                                    <div class="col_25 float_left">
                                        <img src="upload/<?php echo $RstObj['img_path']; ?>" alt="No Product-Pic" style="width:90px; height:70px;" />
                                    </div>
                                    <div class="col_75 float_left">
                                        <div class="row_100" style="margin-left:10px;">
                                            <?php echo $RstObj['title']; ?>
                                        </div>
                                        <div class="row_100" style="margin-left:10px;">
                                            <div class="col_65 float_left">
                                                <?php echo $RstObj['quantity']; ?> X 
                                                <?php echo $RstObj['unitprice']; ?>
                                            </div>
                                            <div class="col_35 float_left" style="text-align:right;">
                                                <a href="delete_cart.php?id=<?php echo $ItemID; ?>"><i class="fa fa-close" style="margin-right:10px;"></i></a>
                                            </div>
                                        </div>        
                                    </div>
								</div>
                                <div class="row_100 x_10"></div>
								<?php
									$Amount = $Amount+ $RstObj['totalamount'];
                                }
                                ?>
                                <div class="row_100">
                                    <div class="col_25 float_left">
                                        <h4>Total Amount</h4>
                                    </div>
                                    <div class="col_75 float_left">
                                        <h4 style="margin-left:10px;">
                                        Rs.
										<?php
                                            echo $Amount;
                                        ?>
                                        </h4>
                                    </div>
                             	</div>
                            	<div class = "modal-footer">
                                    <button name="BuyCart" class="button1">Submit</button>
                                    <button type="button" class="button1" data-dismiss="modal">Close</button>
                                </div>
							<?php    
							}
							else
							{
						?>		
                            <div class="row_100">
                                <h4>&nbsp; &nbsp; Cart Is Empty...</h4>
                                <h2> </h2>
                            </div>
						<?php	
                            }
						?>        
                    </div>
       			</form>
            </div>
        </div>  
	</div>
</div>
<?php
	if(isset($_POST['BuyCart']))
	{
		$Query  = "SELECT * FROM addcart WHERE customer_id=".$CustomerId;
		$Result = mysqli_query($conn,$Query);
		while($RstObj = mysqli_fetch_array($Result))
		{
			$Invice = $RstObj['inviceno']; 
			$Query  = "INSERT INTO buycart(inviceno, customer_id, product_id, title, img_path, quantity, unitprice, totalamount) 
		    Values('".$Invice."', ".$CustomerId.", ".$RstObj['product_id'].", '".$RstObj['title']."', '".$RstObj['img_path']."', ".$RstObj['quantity'].", 
		    ".$RstObj['unitprice'].", ".$RstObj['totalamount'].")";
			mysqli_query($conn,$Query);
		}
		$Query  = "DELETE FROM addcart WHERE customer_id=".$CustomerId;
		mysqli_query($conn,$Query);
		$Query  = "INSERT INTO billingcart(inviceno, customer_id, totalamount, orderdate, recieveamount, paymentdate, balance, bill_status, status) 
		Values('".$Invice."', ".$CustomerId.", ".$Amount.", '".date("d:m:Y :: h:i:s")."',  0, '0', ".$Amount.", 0, 0)";
		mysqli_query($conn,$Query);
		header("location:submitfile.php?id=$CustomerId");
	}
?>