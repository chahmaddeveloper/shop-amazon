<?php
	ob_start();
	session_start();
	$PageName = "laptops.php";
	$Path = "";
	include('lib/opencon.php');
	$ReqID  = $_GET['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $Title; ?></title>
    <link href="css/font-awesome.css" rel="stylesheet" />
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
</head>
<body>
    <div style="padding:0px 0px; margin:0px 0px; top:0; width:100%;">
        <?php 
            include('header.php');
        ?>
    </div>
    <?php 
		include('navbar2.php');
	?>
    <div class="row_100">
    	<div class="wrapper">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_30">
                    <div class="row_100">
                        <small class="txt_37">
                            <i  style="font-size:36px; color:#0085c3; text-shadow:none;" class="fa fa-cart-plus"></i> 
                            &nbsp; Our Products
                        </small>
                    </div>
                    <div class="row_100 x_10">
                    <?php
                        $Query  = "SELECT * FROM products WHERE menu_id =".$ReqID;
                        $Result = mysqli_query($conn,$Query);
                        if(mysqli_num_rows($Result) > 0)
                        {
                            while($RstObj = mysqli_fetch_array($Result))
                            {
                                $ProductID = $RstObj['id'];
                            ?>
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 x_10">
                                <div class="row_100 banner3 shadow">
                                    <div class="row_100 x_02 left_02 right_02 bottom_02">
                                        <div class="row_100" style="height:200px;">
                                            <img src="upload/<?php echo $RstObj['img_path']; ?>" alt="<?php echo $RstObj['title']; ?>" style="height:200px; width:100%;" />
                                        </div>
                                        <div class="row_100 bg_banner x_02">
                                            <div class="row_97">
                                                <div class="row_100">
                                                    <div class="row_100">
                                                        <span class="txt_manager1"><?php echo $RstObj['title']; ?></span>
                                                    </div>
                                                    <div class="row_100" style="height:70px">
                                                        <small class="txt_description"><?php echo $RstObj['description']; ?></small>
                                                    </div>
                                                    <div class="row_100">
                                                        <div class="col_50 float_left">
                                                            <span class="txt_manager3">RS.  <span class="txt_manager2"><?php echo $RstObj['price']; ?></span></span>
                                                        </div>
                                                        <div class="col_50 float_left x_05" style="text-align:right;"></div>
                                                    </div>
                                                </div>
                                                <div class="row_100 x_05">
                                                    <center>
                                                        <a href="detail.php?idproduct=<?php echo $ProductID; ?>" >
                                                            <input type="button" value="Buy Now" class="button" />
                                                        </a>
                                                    </center>
                                                </div>
                                                <div class="row_100 x_10"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="padding-top:7px;"></div>
                            </div>
                            <?php
                            }
                        }
                        else
                        {
                        ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_10">
                                <h4 class="txt_msg">Sorry! No Product Exist In Stock....</h4>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:150px;"></div>
                        <?php	
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
   	</div>
    <div class="row_100" style="margin-top:70px;">
        <?php include('footer.php'); ?>
	</div>
</body>
</html>