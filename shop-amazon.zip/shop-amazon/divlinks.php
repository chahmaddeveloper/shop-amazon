<div class="row_100 x_05" style="background:#0085c3;" style="margin:0px; padding:0px;">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <ul class="icon2">
            <li>
                <a href="#">
                    <div class="icon2-div">
                        <i class="fa fa-facebook-f"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="icon2-div">
                        <i class="fa fa-twitter"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="icon2-div">
                        <i class="fa fa-google-plus"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="icon2-div">
                        <i class="fa fa-vine"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="icon2-div">
                        <i class="fa fa fa-vimeo"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="mailto:info@laptopchannel.com.pk" title="Email">
                    <div class="icon2-div">
                        <i class="fa fa-mail-reply-all"></i>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>