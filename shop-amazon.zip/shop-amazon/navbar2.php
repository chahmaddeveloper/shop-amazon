<link href="ddmenu/ddmenu.css" rel="stylesheet" type="text/css" />
<script src="ddmenu/ddmenu.js" type="text/javascript"></script>
<nav id="ddmenu" style="z-index:10">
    <div class="menu-icon"></div>
    <ul>
        <?php
		$Query  = "SELECT * FROM product_menu";
		$Result = mysqli_query($conn,$Query);
		while($RstObj = mysqli_fetch_object($Result))
		{
			$MenuID = $RstObj->menu_id;
		?>
        <li class="full-width">
            <span class="top-heading">
            	<a href="productsmenu.php?id=<?php echo $MenuID;?>">
					<?php echo($RstObj->product); ?>
                </a>
            </span>
            <i class="caret"></i>
            <div class="dropdown">
                <div class="dd-inner">
                    <ul class="column">
                        <?php
						$Query1  = "SELECT * FROM product_sub WHERE menu_id = ".$MenuID;
						$Result1 = mysqli_query($conn,$Query1);
						while($RstSub = mysqli_fetch_array($Result1))
						{
						?>
                        <li>
                        	<a href="productspro.php?id=<?php echo($RstSub['sub_id']); ?>">
                            	<b><?php echo($RstSub['product']); ?></b>
                            </a>
                        </li>
                        <?php
						}
						?>
                    </ul>
                </div>
            </div>
        </li>
        <?php
		}
		?>
    </ul>
</nav>