<?php
	$PageName = "";
	$Path = "";
	include('lib/opencon.php');
	
	
	if(!isset($_REQUEST['id']))
	{
		$ReqID = "";
		
	}
	else
	{
		$ReqID = $_GET['id'];
		if($ReqID == 'done')
		{
			$ReqID = "You have successfully created your account ";
		}
	}
	
	
	if(isset($_POST['login']))
	{
		$Query  = "SELECT * FROM customeronline WHERE email = '".$_POST['txtmail']."' AND password = '".$_POST['txtpassword']."' ";
		$Result = mysqli_query($conn,$Query);
		if($Result) 
		{
			if(mysqli_num_rows($Result) > 0)
		   	{
				session_start();
				session_regenerate_id();
				$member = mysqli_fetch_assoc($Result);
				$_SESSION['Customer_ID'] = $member['customer_id'];
				$_SESSION['Customer_USER'] = $member['email'];
				$_SESSION['Customer_PASS'] = $member['password'];
				session_write_close();
				$Query = "UPDATE customeronline SET lastlogin_date = '".date("d:m:Y :: h:i:s")."' ";
				mysqli_query($conn,$Query);
				header("location:index.php");
				exit();
			}
			else
			{
				$ReqID = "Email and Password are Wrong. You are not Lon In...!";
			?>
            <script>
				alert("Email and Password are Wrong. You are not Lon In...!");
			</script>
            <?php
			}
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $Title; ?></title>
    
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    
    <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
    
	<script type="text/javascript" language="javascript">
	function LogIn()
	{	
		if(document.FormLogIn.txtmail.value == "")
		{
		    alert("Please Enter E-mail ! ");
		    document.FormLogIn.txtmail.focus();
		    return false;  
		}
		if(document.FormLogIn.txtpassword.value == "")
		{
		    alert("Please Enter Password");
		    document.FormLogIn.txtpassword.focus();
		    return false;  
		}
	}
	</script>    
</head>
<body>
    <div style="padding:0px 0px; margin:0px 0px; top:0; width:100%;">
    	<?php include('header.php'); ?>
    </div>
    <?php 
		include('navbar2.php');
	?>
    <div class="row_100">        
        <div class="row">
            <form name="FormLogIn" method="post">
            <div class="container">    
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 x_20">
                        <div class="row_99 border_1" style="border-radius:13px;">
                            <div class="row_100" style="background:#0085c3; border-radius:13px; padding:9px 0px;">
                                <small style="color:#fff; font-size:24px;"><center>Log In</center></small>
                            </div>
                            <div class="row_80 x_20">
                                <h4><a><?php echo $ReqID; ?></a></h4>
                            </div>
                            <div class="row_80 x_10"></div>
                            <div class="row_80 x_20">
                                <div class="float_left col_40 label1">
                                    E-mail* &nbsp;&nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="email" name="txtmail" placeholder=" E-mail" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_80 x_20"></div>
                            <div class="row_80 x_10">
                                <div class="float_left col_40 label1">
                                    Password* &nbsp;&nbsp; &nbsp;
                                </div>
                                <div class="float_left col_60">
                                    <input type="password" name="txtpassword" class="input_reg" placeholder=" Password" />
                                </div>
                            </div>
                            <div class="row_80 x_20"></div>
                            <div class="row_80 x_10"></div>
                            <div class="row_80">
                                <div class="col_40 float_left x_05"></div>
                                <div class="col_60 float_left"><input type="submit" name="login" class="button-login" onClick="return LogIn();" value="Log In"  /></div>
                            </div>
                            <div class="row_80 x_10">
                                <div class="col_50 float_left x_05"></div>
                                <div class="col_50 float_left">
                                    <h5 style="color:rgb(144,144,144);">If you have no account so please<br />
                                    <a href="signup.php" class="txt_signup"><b>Sign Up</b></a></h5>
                                </div>
                            </div>
                            <div class="row_80 x_20"></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_10"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div> 
            </div>
            </form>
        </div>
    </div>
    <div class="row_100">
    	<?php include('footer.php'); ?>
	</div>
</body>
</html>