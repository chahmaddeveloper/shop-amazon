-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 15, 2016 at 09:21 PM
-- Server version: 5.1.32
-- PHP Version: 5.2.9-1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ah-shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcart`
--

CREATE TABLE IF NOT EXISTS `addcart` (
  `inviceno` varchar(11) NOT NULL,
  `customer_id` int(8) NOT NULL,
  `product_id` int(8) NOT NULL,
  `title` varchar(50) NOT NULL,
  `img_path` varchar(210) NOT NULL,
  `quantity` int(2) NOT NULL,
  `unitprice` int(4) NOT NULL,
  `totalamount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addcart`
--

INSERT INTO `addcart` (`inviceno`, `customer_id`, `product_id`, `title`, `img_path`, `quantity`, `unitprice`, `totalamount`) VALUES
('InvNo9', 1, 15, 'Kurta', 'arj-6155-1881663-1-zoom.jpg', 2, 2200, 4400);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `phone` varchar(17) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`, `phone`, `status`) VALUES
(1, 'ahmad', 'admin', 'project', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `billingcart`
--

CREATE TABLE IF NOT EXISTS `billingcart` (
  `inviceno` varchar(22) NOT NULL,
  `customer_id` int(8) NOT NULL,
  `totalamount` double NOT NULL,
  `orderdate` varchar(30) NOT NULL,
  `recieveamount` double NOT NULL,
  `paymentdate` varchar(30) NOT NULL,
  `balance` double NOT NULL,
  `bill_status` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billingcart`
--

INSERT INTO `billingcart` (`inviceno`, `customer_id`, `totalamount`, `orderdate`, `recieveamount`, `paymentdate`, `balance`, `bill_status`, `status`) VALUES
('InvNo1', 1, 11200, '08:08:2016 :: 06:24:00', 0, '0', 11200, 0, 1),
('InvNo2', 1, 19800, '08:08:2016 :: 06:25:01', 0, '0', 19800, 0, 0),
('InvNo3', 1, 2480, '22:08:2016 :: 10:25:09', 0, '0', 2480, 0, 0),
('InvNo4', 1, 14400, '08:09:2016 :: 02:06:46', 0, '0', 14400, 0, 0),
('InvNo5', 1, 6064, '08:09:2016 :: 10:19:43', 0, '0', 6064, 0, 0),
('InvNo6', 1, 2400, '10:09:2016 :: 11:47:39', 0, '0', 2400, 0, 0),
('InvNo7', 1, 5496, '10:09:2016 :: 12:16:37', 0, '0', 5496, 0, 0),
('InvNo8', 1, 1200, '10:09:2016 :: 10:22:16', 0, '0', 1200, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `buycart`
--

CREATE TABLE IF NOT EXISTS `buycart` (
  `inviceno` varchar(22) NOT NULL,
  `customer_id` int(8) NOT NULL,
  `product_id` int(8) NOT NULL,
  `title` varchar(50) NOT NULL,
  `img_path` varchar(230) NOT NULL,
  `quantity` int(4) NOT NULL,
  `unitprice` int(4) NOT NULL,
  `totalamount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buycart`
--

INSERT INTO `buycart` (`inviceno`, `customer_id`, `product_id`, `title`, `img_path`, `quantity`, `unitprice`, `totalamount`) VALUES
('InvNo1', 1, 10, 'Long Shirt', 'download (3).jpg', 2, 3200, 6400),
('InvNo1', 1, 13, 'Long Shirt', '116.jpg', 4, 1200, 4800),
('InvNo2', 1, 12, 'Long Shirt', 'download (2).jpg', 11, 1800, 19800),
('InvNo3', 1, 9, 'Shirt', '14.jpg', 2, 1240, 2480),
('InvNo4', 1, 8, 'Kurta', '4.jpg', 1, 1200, 1200),
('InvNo4', 1, 13, 'Long Shirt', '116.jpg', 3, 1200, 3600),
('InvNo4', 1, 12, 'Long Shirt', 'download (2).jpg', 4, 1800, 7200),
('InvNo4', 1, 8, 'Kurta', '4.jpg', 2, 1200, 2400),
('InvNo5', 1, 8, 'Kurta', '4.jpg', 2, 1200, 2400),
('InvNo5', 1, 11, 'Long Shirt', 'images (4).jpg', 2, 1832, 3664),
('InvNo6', 1, 8, 'Kurta', '4.jpg', 2, 1200, 2400),
('InvNo7', 1, 11, 'Long Shirt', 'images (4).jpg', 3, 1832, 5496),
('InvNo8', 1, 8, 'Kurta', '4.jpg', 1, 1200, 1200);

-- --------------------------------------------------------

--
-- Table structure for table `customeronline`
--

CREATE TABLE IF NOT EXISTS `customeronline` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(15) NOT NULL,
  `lastname` varchar(15) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(25) NOT NULL,
  `address` varchar(120) NOT NULL,
  `town` varchar(40) NOT NULL,
  `city` varchar(32) NOT NULL,
  `phone` varchar(17) NOT NULL,
  `country` varchar(25) NOT NULL,
  `signup_date` varchar(32) NOT NULL,
  `lastlogin_date` varchar(32) NOT NULL,
  `update_date` varchar(25) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customeronline`
--

INSERT INTO `customeronline` (`customer_id`, `firstname`, `lastname`, `email`, `password`, `address`, `town`, `city`, `phone`, `country`, `signup_date`, `lastlogin_date`, `update_date`) VALUES
(1, 'Ahmad', 'Raza', 'ahmad@yahoo.com', '12345678', 'Market stop No.10', 'farid town', 'Sahiwal', '03227064463', 'Pakistan', '30:04:2016 :: 01:11:50', '15:10:2016 :: 11:47:54', '17:09:2016 :: 10:13:43'),
(2, 'Ahmad', 'Raza', 'ahmad@yahoo.com', 'ahmad123', '316 G block ', 'Farid Town', 'Sahiwal', '03048563830', 'Pakistan', '05:09:2016 :: 10:30:46', '15:10:2016 :: 11:47:54', ''),
(3, '', '', '', '', '', '', '', '', 'q', '17:09:2016 :: 05:27:58', '15:10:2016 :: 11:47:54', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(9) NOT NULL,
  `sub_id` int(9) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(220) NOT NULL,
  `price` int(5) NOT NULL,
  `img_path` varchar(220) NOT NULL,
  `stock` int(5) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `menu_id`, `sub_id`, `title`, `description`, `price`, `img_path`, `stock`, `status`) VALUES
(8, 2, 1, 'Kurta', 'Men Kurta for summer seasson', 1200, 'arj-5765-0748802-3-zoom.jpg', 12, 0),
(10, 3, 20, 'Long Shirt', 'Women long shirt  for summer seasson', 3200, 'download (3).jpg', 41, 0),
(11, 3, 20, 'Long Shirt', 'Women long shirt  for 14th August special', 1832, 'images (4).jpg', 16, 0),
(12, 3, 20, 'Long Shirt', 'Women long shirt  for summer seasson', 1800, 'download (2).jpg', 41, 0),
(13, 3, 20, 'Long Shirt', 'Women long shirt  for winter seasson', 1200, '116.jpg', 32, 0),
(14, 2, 1, 'Kurta', 'men kurta for summer season ', 3110, 'arj-3641-835761-3-zoom.jpg', 300, 0),
(15, 2, 1, 'Kurta', 'men kurta for summer season  ', 2200, 'arj-6155-1881663-1-zoom.jpg', 12, 0),
(16, 2, 1, 'Kurta', 'men kurta for summer season ', 5500, 'arj-5747-9648802-1-zoom.jpg', 3, 0),
(19, 8, 24, 'Dell i5', 'Ram 4 GB , Hard 1000GB', 45000, 'dell-5336-2157645-3-zoom.jpg', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_menu`
--

CREATE TABLE IF NOT EXISTS `product_menu` (
  `menu_id` int(9) NOT NULL AUTO_INCREMENT,
  `product` varchar(32) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `product_menu`
--

INSERT INTO `product_menu` (`menu_id`, `product`) VALUES
(2, 'Men Fashion'),
(3, 'Women Fashion'),
(4, 'Kids Fashion'),
(5, 'Beauty Products'),
(8, 'Laptops');

-- --------------------------------------------------------

--
-- Table structure for table `product_sub`
--

CREATE TABLE IF NOT EXISTS `product_sub` (
  `menu_id` int(9) NOT NULL,
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(41) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `product_sub`
--

INSERT INTO `product_sub` (`menu_id`, `sub_id`, `product`) VALUES
(2, 1, 'Kurta'),
(2, 2, 'T-shirt'),
(2, 3, 'Men Jeans'),
(2, 5, 'Un-Stitching Clothe'),
(2, 6, 'Stitching Clothe '),
(2, 7, 'Dress Peant'),
(3, 8, 'Women Kurta'),
(3, 9, 'Women T-shirt'),
(3, 10, 'Women Jeans'),
(3, 11, 'Un-Stitching Clothe'),
(3, 12, 'Stitching Clothe '),
(4, 13, 'Kids Shirt'),
(4, 14, 'Kids Jeans'),
(4, 15, 'Peant shirt'),
(5, 17, 'Perfume'),
(2, 19, 'Shirt'),
(3, 20, 'Women Shirt'),
(4, 21, 'Baby Toys'),
(4, 22, 'Kids Toy'),
(5, 23, 'Lipstic'),
(8, 24, 'Dell Laptop');

-- --------------------------------------------------------

--
-- Table structure for table `sitedetails`
--

CREATE TABLE IF NOT EXISTS `sitedetails` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `address` varchar(66) NOT NULL,
  `city` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sitedetails`
--


-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `pic_path` varchar(200) NOT NULL,
  `pic_alt` varchar(70) NOT NULL,
  `title` varchar(60) NOT NULL,
  `description` varchar(220) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `slider`
--

