<?php
	ob_start();
	session_start();
	$PageName = "";
	$Path = "";
	include('lib/opencon.php');	
	if(isset($_POST['signup']))
	{
		$Query = "INSERT INTO customeronline(customer_id, firstname, lastname, email, password, address, town, city, phone, country, signup_date)
		VALUES('Null', '".$_POST['txtfname']."', '".$_POST['txtlname']."', '".$_POST['txtmail']."',
		'".$_POST['txtpassword']."', '".$_POST['txtaddress']."', '".$_POST['txttown']."', 
		'".$_POST['txtcity']."', '".$_POST['txtphone']."', '".$_POST['txtcountry']."', '".date("d:m:Y :: h:i:s")."' )";
		
		mysql_query($Query);
		$Message = "done";
		header("location:register.php?id=$Message");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $Title; ?></title>
    
    <link href="boot/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="boot/startbootstrap.css" rel="stylesheet" type="text/css">
    
    <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- JavaScript -->
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="boot/startbootstrap.js"></script>
	
	<script type="text/javascript" language="javascript">
    function SignUp()
    {  
        if(document.FormSignUp.txtfname.value == "" )
        {
            alert("Please Enter First Name ! ");
            document.FormSignUp.txtfname.focus();
            return false;
        }
        if(document.FormSignUp.txtfname.value != "" )
        {
            if( isNaN(document.FormSignUp.txtfname.value) == false )
            {
                alert("Please Enter First Name In Alphabates ! ");
                document.FormSignUp.txtfname.focus();
                return false;
            }
            else if( isNaN(document.FormSignUp.txtfname.value) == true )
            {
                if(document.FormSignUp.txtfname.value.length <= 2 )
                {
                    alert("Name Must Be Greater Than 2 Letters  ! ");
                    document.FormSignUp.txtfname.focus();
                    return false;
                }
            }
        }
		if(document.FormSignUp.txtlname.value == "")
		{
			alert("Please enter last name");
		    document.FormSignUp.txtlname.focus();
		    return false;
		}
		if(document.FormSignUp.txtlname.value != "" )
        {
            if( isNaN(document.FormSignUp.txtlname.value) == false )
            {
                alert("Please Enter Last Name In Alphabates ! ");
                document.FormSignUp.txtlname.focus();
                return false;
            }
            else if( isNaN(document.FormSignUp.txtlname.value) == true )
            {
                if(document.FormSignUp.txtlname.value.length <= 1 )
                {
                    alert("Name Must Be Greater Than 1 Letters  ! ");
                    document.FormSignUp.txtlname.focus();
                    return false;
                }
            }
        }
		if(document.FormSignUp.txtmail.value == "")
		{
		    alert("Please Enter E-mail ! ");
		    document.FormSignUp.txtmail.focus();
		    return false;  
		}
		if(document.FormSignUp.txtmail.value != "" )
        {
			if(document.FormSignUp.txtmail.value.length <= 7 )
			{
				alert("E-Mail At Least Contain 8 Words  ! ");
				document.FormSignUp.txtmail.focus();
				return false;
			}
        }
		if(document.FormSignUp.txtpassword.value == "")
		{
		    alert("Please Enter Password");
		    document.FormSignUp.txtpassword.focus();
		    return false;  
		}
		if(document.FormSignUp.txtpassword.value != "" )
        {
			if(document.FormSignUp.txtpassword.value.length <= 7 )
			{
				alert("Password At Least Contain 8 Words  ! ");
				document.FormSignUp.txtpassword.focus();
				return false;
			}
        }
		if(document.FormSignUp.txtaddress.value == "")
		{
		    alert("Please Enter Address");
		    document.FormSignUp.txtaddress.focus();
		    return false;  
		}
		if(document.FormSignUp.txttown.value == "")
		{
		    alert("Please Enter Town");
		    document.FormSignUp.txttown.focus();
		    return false;
		}
		if(document.FormSignUp.txttown.value != "")
		{
			if(document.FormSignUp.txttown.value.length <= 2 )
			{
		    	alert("Please Enter Full Town Name! ");
		    	document.FormSignUp.txttown.focus();
		    	return false;
			}
		}
		if(document.FormSignUp.txtcity.value == "")
		{
		    alert("Please Enter City");
		    document.FormSignUp.txtcity.focus();
		    return false;
		}
		if(document.FormSignUp.txtcity.value != "")
		{
			if( isNaN(document.FormSignUp.txtcity.value) == false )
            {
                alert("Please Enter Correct City Name ! ");
                document.FormSignUp.txtcity.focus();
                return false;
            }
            else if( isNaN(document.FormSignUp.txtcity.value) == true )
            {
                if(document.FormSignUp.txtcity.value.length <= 3 )
                {
                    alert("Please Enter Full And Correct City Name ! ");
                    document.FormSignUp.txtcity.focus();
                    return false;
                }
            }
		}
		if(document.FormSignUp.txtphone.value == "")
		{
		    alert("Please Enter Phone Number");
		    document.FormSignUp.txtphone.focus();
		    return false;  
		}
		if(document.FormSignUp.txtphone.value != "")
		{
		    if( isNaN(document.FormSignUp.txtphone.value) == true )
            {
                alert("Please Enter Correct Mobile Number Becuase Online Shopping Order Confirmation Is Send On Your Mobile ! ");
                document.FormSignUp.txtcountry.focus();
                return false;
            }
            else if( isNaN(document.FormSignUp.txtphone.value) == false )
            {
                if(document.FormSignUp.txtphone.value.length <= 3 )
                {
                    alert("Please Enter Full And Correct Mobile Number ! ");
                    document.FormSignUp.txtcountry.focus();
                    return false;
                }
            }  
		}
		if(document.FormSignUp.txtcountry.value == "")
		{
		    alert("Please Enter Country Name !");
		    document.FormSignUp.txtcountry.focus();
		    return false;
		}
		if(document.FormSignUp.txtcountry.value != "")
		{
			if( isNaN(document.FormSignUp.txtcountry.value) == false )
            {
                alert("Please Enter Correct Country Name ! ");
                document.FormSignUp.txtcountry.focus();
                return false;
            }
            else if( isNaN(document.FormSignUp.txtcountry.value) == true )
            {
                if(document.FormSignUp.txtcountry.value.length <= 3 )
                {
                    alert("Please Enter Full And Correct Country Name ! ");
                    document.FormSignUp.txtcountry.focus();
                    return false;
                }
            }
		}
    }	
    </script>	
</head>
<body>
    <div class="row_100">
        <header>
            <?php include('header.php'); ?>
        </header>
    </div>
    <?php 
		include('navbar2.php');
	?>
    <div class="row_100">        
        <div class="row">
            <form name="FormSignUp" method="post">
            <div class="container">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_10">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 x_10">
                        <div class="border_1" style="border-radius:13px;">
                            <div class="row_100" style="background:#0085c3; border-radius:13px; padding:9px 0px;">
                                <small style="color:#fff; font-size:24px;"><center>Registration</center></small>
                            </div>
                            <div class="row_90 x_20"></div>
                            <div class="row_95 x_05">
                                <div class="float_left col_40 label1">
                                    First Name* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtfname" placeholder=" First Name" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Last Name* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtlname" placeholder=" Last Name" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    E-mail* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="email" name="txtmail" placeholder=" E-mail" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Password* &nbsp;&nbsp; &nbsp;
                                </div>
                                <div class="float_left col_60">
                                    <input type="password" name="txtpassword" class="input_reg" placeholder=" Password" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Confirm Password* &nbsp;
                                </div>
                                <div class="float_left col_60">
                                    <input type="password" name="txtconpassword" class="input_reg" placeholder=" Confirm Password" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Address* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtaddress" placeholder=" Address" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Town* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txttown" placeholder=" Town" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    City* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtcity" placeholder=" City" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Phone* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtphone" placeholder=" Phone" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_95 x_10">
                                <div class="float_left col_40 label1">
                                    Country* &nbsp; &nbsp; 
                                </div>
                                <div class="float_left col_60">
                                    <input type="text" name="txtcountry" placeholder=" Country" class="input_reg" />
                                </div>
                            </div>
                            <div class="row_80 x_20"></div>
                            <div class="row_95">
                                <div class="col_40 float_left x_05"></div>
                                <div class="col_60 float_left"><input type="submit" onclick="return SignUp();" name="signup" class="button-login" value="Sign Up"  /></div>
                            </div>
                            <div class="row_80 x_20"></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 x_05"></div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 x_20"></div> 
            </div>
            </form>
        </div>
    </div>    
    <div>
    	<?php include('footer.php'); ?>
	</div>
</body>
</html>